# inkhala.github.io
Blog for ACM team
Installation:  
1. fork this repository to your own Github account.
2. Download it and unzip the file teamblog.zip
3. Install nodejs and hexo: the link is here: https://xuanwo.org/2015/03/26/hexo-intor/
4. if you want to add a post, just copy your markdown file to  _teamblog/source/_post_, and execute the following command:  
```
hexo generate
```
5. commit the public file to your repository and then open a pull request.  
